﻿namespace JLPlugin.Data
{
    [System.Serializable]
    public class attackSlots
    {
        public bool runOnSlotCondition;
        public slotData slot;
        public string damage;
    }
}