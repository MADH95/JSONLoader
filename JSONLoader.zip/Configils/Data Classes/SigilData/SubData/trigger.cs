﻿namespace JLPlugin.Data
{
    [System.Serializable]
    public class trigger
    {
        public string triggerType;
        public string activatesForCardsWithCondition;
    }
}