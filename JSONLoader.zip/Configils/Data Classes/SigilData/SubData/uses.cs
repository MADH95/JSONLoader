﻿namespace JLPlugin.Data
{
    [System.Serializable]
    public class uses
    {
        public string amountOfTurns;
        public string amountOfTriggerActivations;
    }
}