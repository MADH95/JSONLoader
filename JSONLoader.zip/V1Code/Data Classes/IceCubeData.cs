﻿
namespace JLPlugin.Data
{
    public class IceCubeData
    {
        public string creatureWithin;
    }
}
