﻿
namespace JLPlugin.Data
{
    using Utils;

    public class TailData
    {
        public string name;
        public string tailLostPortrait;
    }
}
