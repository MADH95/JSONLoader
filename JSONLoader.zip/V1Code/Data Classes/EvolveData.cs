﻿
namespace JLPlugin.Data
{
    public class EvolveData
    {
        public string name;
        public int turnsToEvolve;
    }
}
