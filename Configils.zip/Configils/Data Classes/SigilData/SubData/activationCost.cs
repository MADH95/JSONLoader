﻿namespace JLPlugin.Data
{
    [System.Serializable]
    public class activationCost
    {
        public int? bonesCost;
        public int? energyCost;
    }
}