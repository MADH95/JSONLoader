﻿using System.Collections.Generic;

namespace JLPlugin.Data
{
    [System.Serializable]
    public class extraAttacks
    {
        public string removeNormalAttack;
        public List<slotData> slots;
    }
}