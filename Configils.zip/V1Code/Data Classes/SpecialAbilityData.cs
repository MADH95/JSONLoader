﻿
namespace JLPlugin.Data
{
    [System.Serializable]
    public class SpecialAbilityData
    {
        public string name;
        public string GUID;
    }
}
