﻿
namespace JLPlugin.Data
{
    [System.Serializable]
    public class AbilityData
    {
        public string name;
        public string GUID;
    }
}